import { InD } from "./InD/InD.js";

const ind = new InD();