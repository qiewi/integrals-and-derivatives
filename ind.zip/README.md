# ind-game
🧩 ind-Game using only HTML, CSS, and JavaScript
